# GitMiner
 GitMiner - Mining tool for Git project platforms

