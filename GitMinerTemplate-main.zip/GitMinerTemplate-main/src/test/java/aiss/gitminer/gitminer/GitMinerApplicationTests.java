package aiss.gitminer.gitminer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GitMinerApplicationTests {

	@Test
	void contextLoads() {
	}

}
